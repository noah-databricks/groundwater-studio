"""Auto-generated at wheel build time; do not edit.

This module is created by ``setup.py`` immediately before
``build_py`` packages the wheel, and is gitignored so it
is recreated on every build. Consumers should import it
defensively (``try: from omnigent import _build_info``)
because source checkouts that have never been built will
not have it on disk.
"""
from __future__ import annotations

BUILD_TIME_EPOCH: int = 1790416648
COMMIT_SHA: str = '16e9c00dffeabfcfde5617943886f85abe85b25a'

"""Process-agnostic, read-only workspace filesystem reader.

The runner serves the web UI's file panel (directory browse, changed
files, diffs, search, file content) by reading its sandboxed
workspace.  When the runner process dies but the host that holds the
workspace on disk is still connected, the host serves the same panel by
running this module against the workspace directory directly.

This reader is deliberately *read-only* and *sandbox-free*: it never
writes, never runs a shell, and confines every path to the workspace
root.  It reuses the runner's pure helpers (glob translation, path
validation, pagination, the git/edit change registry) so the JSON it
returns is byte-identical to the runner's filesystem endpoints — the
server proxy layer and the frontend cannot tell which side answered.

The returned dicts match, one-to-one, the runner endpoints in
``omnigent/runner/app.py``:

- :meth:`WorkspaceReader.list_or_read` → ``_fs_list_or_read``
- :meth:`WorkspaceReader.changes`      → ``list_filesystem_changes``
- :meth:`WorkspaceReader.diff`         → ``read_environment_file_diff``
- :meth:`WorkspaceReader.search`       → ``search_environment_files``

Change-tracking caveat: in a **git** workspace the changed-files list
and diff baselines come from ``git status`` / ``git show`` and are fully
reconstructable from disk, so the host serves them exactly like the
runner.  In a **non-git** workspace the runner tracks changes from the
live agent's tool calls (in-memory), which the host does not have — so
the host returns an empty changed-files list there.  Directory browse,
search, and file content work identically in both modes.
"""

from __future__ import annotations

import base64
import mimetypes
import os
import re
from collections import deque
from pathlib import Path
from typing import TypeAlias, cast

from omnigent.entities.environment_filesystem import FilesystemEntry, InvalidPath
from omnigent.entities.pagination import paginate_in_memory
from omnigent.inner._cwd_scan import _DEFAULT_DEPRIORITIZED_DIRS
from omnigent.inner.os_env import _DEFAULT_READ_LIMIT
from omnigent.runner import github_resource
from omnigent.runner.environment_filesystem import (
    _SEARCH_SCAN_BUDGET,
    _glob_to_regex,
    _validate_path,
    entry_payload,
    index_search,
    merge_entries,
    split_glob_list,
)
from omnigent.runtime.filesystem_registry import (
    GitStatusUnavailable,
    create_filesystem_registry,
)

# Match the runner's caps so a host-served read is truncated identically.
_MAX_READ_BYTES = 10 * 1024 * 1024  # 10 MiB

_WorkspacePayload: TypeAlias = dict[str, object]


class WorkspaceReaderError(Exception):
    """A workspace read failed with a specific HTTP-mappable outcome.

    Carries a ``status`` code and an error ``code``/``message`` so the
    host handler can echo the same shape the runner endpoints return
    (404 not-found, 400 invalid-path, 500 git-status-failed).

    :param status: HTTP status the runner would have returned.
    :param code: Machine-readable error code, e.g. ``"not_found"``.
    :param message: Human-readable detail.
    """

    def __init__(self, status: int, code: str, message: str) -> None:
        super().__init__(message)
        self.status = status
        self.code = code
        self.message = message


class WorkspaceReader:
    """Read-only view of a workspace directory, confined to its root.

    :param root: Absolute path to the workspace directory on disk, e.g.
        ``Path("/Users/alice/project")``.
    """

    def __init__(self, root: Path) -> None:
        self._root = Path(root).resolve()
        # The change registry (git or edit-tracking) is chosen the same
        # way the runner chooses it, so git workspaces get git-status
        # semantics and everything else degrades to an empty list.
        self._registry = create_filesystem_registry(self._root)
        self._registry.start()

    # ── Path confinement ──────────────────────────────────────────

    def _resolve(self, path: str) -> Path:
        """Resolve a relative path to an absolute path under the root.

        :param path: Relative path within the workspace (``""`` = root).
        :returns: Resolved absolute path guaranteed under the root.
        :raises WorkspaceReaderError: 400 when the path escapes the root
            or is otherwise invalid.
        """
        try:
            validated = _validate_path(path) if path else ""
        except InvalidPath as exc:
            raise WorkspaceReaderError(400, "invalid_path", str(exc)) from exc
        if not validated:
            return self._root
        full = (self._root / validated).resolve()
        try:
            full.relative_to(self._root)
        except ValueError as exc:
            raise WorkspaceReaderError(
                400, "invalid_path", f"Path {path!r} escapes the workspace root"
            ) from exc
        return full

    # ── Directory listing / file content ──────────────────────────

    def list_or_read(
        self,
        path: str,
        *,
        limit: int = 20,
        after: str | None = None,
        before: str | None = None,
        order: str = "desc",
    ) -> _WorkspacePayload:
        """List a directory or read a file, mirroring ``_fs_list_or_read``.

        :param path: Relative path (``""`` for the workspace root).
        :param limit: Max entries for a directory listing.
        :param after: Forward-pagination cursor entry id.
        :param before: Backward-pagination cursor entry id.
        :param order: Sort order, ``"asc"`` or ``"desc"``.
        :returns: A directory-listing dict or a file-content dict.
        :raises WorkspaceReaderError: On invalid path or missing file.
        """
        resolved = self._resolve(path)
        if resolved.is_dir():
            return self._list_dir(path, resolved, limit, after, before, order)
        return self._read_file(path, resolved)

    def _list_dir(
        self,
        rel: str,
        resolved: Path,
        limit: int,
        after: str | None,
        before: str | None,
        order: str,
    ) -> _WorkspacePayload:
        """Build the directory-listing payload for a resolved directory.

        Classifies entries by target type (follows symlinks) and skips
        per-entry ``OSError`` (e.g. a broken symlink) so one bad entry
        does not fail the listing — matching the runner's ``list_dir``.
        """
        validated = _validate_path(rel) if rel else ""
        entries: list[_WorkspacePayload] = []
        try:
            names = sorted(os.listdir(resolved))
        except OSError as exc:
            raise WorkspaceReaderError(
                404, "not_found", f"Directory {rel!r} not found or not accessible"
            ) from exc
        for name in names:
            full = resolved / name
            child_rel = os.path.join(validated, name) if validated else name
            try:
                st = full.stat()  # follows symlinks, like the runner
                is_dir = full.is_dir()
                entry_type = "directory" if is_dir else "file"
                size = st.st_size if entry_type == "file" else None
                mtime = int(st.st_mtime)
            except OSError:
                # Broken symlink (target gone): fall back to lstat and list it
                # as a file with no size, matching the runner's list_dir rather
                # than dropping the entry.
                try:
                    ls = full.lstat()
                except OSError:
                    continue
                entry_type = "file"
                size = None
                mtime = int(ls.st_mtime)
            entries.append(
                {
                    "id": child_rel,
                    "object": "session.environment.filesystem.entry",
                    "name": name,
                    "path": child_rel,
                    "type": entry_type,
                    "bytes": size,
                    "modified_at": mtime,
                }
            )
        page = paginate_in_memory(
            entries,
            id_fn=lambda entry: cast(str, entry["id"]),
            limit=limit,
            after=after,
            before=before,
            order=order,
        )
        return {
            "object": "list",
            "data": page.data,
            "first_id": page.first_id,
            "last_id": page.last_id,
            "has_more": page.has_more,
        }

    def _read_file(
        self,
        rel: str,
        resolved: Path,
        *,
        limit: int | None = _DEFAULT_READ_LIMIT,
    ) -> _WorkspacePayload:
        """Build the file-content payload for a resolved file.

        Text files are UTF-8 decoded and line-capped at ``limit``; binary
        files are base64-encoded.  Both are byte-capped at
        :data:`_MAX_READ_BYTES`.  Shape matches the runner's file-content
        response, including the mimetype guess.

        Reads at most ``_MAX_READ_BYTES`` from disk (like the runner's
        bounded read) rather than slurping the whole file, so opening a
        multi-GB file in the viewer can't OOM the host process.
        """
        try:
            with resolved.open("rb") as fh:
                # One extra byte lets us detect (and flag) truncation
                # without loading the rest of a large file into memory.
                capped = fh.read(_MAX_READ_BYTES + 1)
        except OSError as exc:
            raise WorkspaceReaderError(404, "not_found", f"Path {rel!r} not found") from exc

        return self._file_content_payload(rel, capped, limit=limit)

    def _file_content_payload(
        self,
        rel: str,
        raw: bytes,
        *,
        limit: int | None,
    ) -> _WorkspacePayload:
        """Assemble the file-content dict from raw bytes."""
        content_type_guess, _ = mimetypes.guess_type(rel)
        truncated = False
        capped = raw
        if len(capped) > _MAX_READ_BYTES:
            capped = capped[:_MAX_READ_BYTES]
            truncated = True

        text: str | None = None
        try:
            text = capped.decode("utf-8")
        except UnicodeDecodeError as exc:
            # A byte-cap truncation can split a multi-byte codepoint at the very
            # end, which would otherwise flip an oversize *text* file to base64.
            # When the only invalid bytes are a partial trailing codepoint (the
            # error starts within the last 3 bytes of the truncated buffer),
            # drop them and retry — matching the runner's boundary-safe
            # truncation so the same file serves as text from either side. A
            # genuinely binary file has invalid bytes earlier in the buffer, so
            # this guard doesn't rescue it and it falls through to base64.
            if truncated and exc.start >= len(capped) - 3:
                capped = capped[: exc.start]
                text = capped.decode("utf-8")

        payload: _WorkspacePayload = {
            "object": "session.environment.filesystem.file_content",
            "path": rel,
            "content_type": content_type_guess,
        }
        if text is not None:
            if limit is not None:
                lines = text.splitlines(keepends=True)
                if len(lines) > limit:
                    text = "".join(lines[:limit])
                    truncated = True
            data = text.encode("utf-8")
            payload["bytes"] = len(data)
            payload["truncated"] = truncated
            payload["encoding"] = "utf-8"
            payload["content"] = text
        else:
            payload["bytes"] = len(capped)
            payload["truncated"] = truncated
            payload["encoding"] = "base64"
            payload["content"] = base64.b64encode(capped).decode()
        return payload

    # ── Search ─────────────────────────────────────────────────────

    def search(
        self,
        query: str,
        *,
        include: str | None = None,
        exclude: str | None = None,
        limit: int = 500,
    ) -> _WorkspacePayload:
        """Search files by substring + glob filters, like the runner.

        :param query: Case-insensitive substring matched against name and
            relative path.  Whitespace-only yields an empty result.
        :param include: Comma-separated include globs (VSCode/Cursor
            subset), e.g. ``"*.ts,src/**"``.
        :param exclude: Comma-separated exclude globs.
        :param limit: Maximum results (capped at 500 by the caller).
        :returns: A list payload of matching file and directory entries. In a
            git workspace tracked files come from the index and untracked
            ones from the latest ``git status`` when one has run; a budgeted
            walk always runs too so ignored files stay findable, and
            ``truncated`` says if it ran out.
        """
        q = query.strip().lower()
        if not q:
            return {"object": "list", "data": [], "has_more": False}

        include_patterns = split_glob_list(include)
        exclude_patterns = split_glob_list(exclude)
        inc = [re.compile(_glob_to_regex(p), re.IGNORECASE) for p in include_patterns]
        exc = [re.compile(_glob_to_regex(p), re.IGNORECASE) for p in exclude_patterns]

        # The budgeted walk below is the only source for ignored files (and,
        # until a ``git status`` has run, untracked ones), so it always runs;
        # git's index adds every tracked file however large the repo, and the
        # latest ``git status`` adds untracked files past the budget.
        indexed = index_search(
            self._registry,
            self._root,
            "",
            q,
            include=include_patterns,
            exclude=exclude_patterns,
            limit=limit,
        )

        results: list[FilesystemEntry] = []
        # State the two-pass walk mutates via closures (rebound through the
        # `nonlocal` in scan()). deferred is a FIFO of noise-dir roots to drain
        # in pass 2.
        deferred: deque[str] = deque()
        scanned = 0
        truncated = False
        stop = False

        # os.walk is handed the absolute root, so an entry's path relative to
        # it is a slice of dirpath -- no per-entry relpath(), whose abspath()
        # work used to dominate the walk's runtime.
        # rstrip: a bare root ("/", "C:\\") already ends in the separator the
        # slice skips.
        cut = len(str(self._root).rstrip(os.sep)) + 1

        def rel(dirpath: str, name: str) -> str:
            # Entries always use '/', like the git-index paths they merge with.
            rel_dir = dirpath[cut:]
            if os.sep != "/":
                rel_dir = rel_dir.replace(os.sep, "/")
            return f"{rel_dir}/{name}" if rel_dir else name

        def match(dirpath: str, name: str, *, is_dir: bool) -> None:
            # A directory carries no byte size; a file stats for size + mtime.
            p = rel(dirpath, name)
            if exc and any(r.match(p) for r in exc):
                return
            if inc and not any(r.match(p) for r in inc):
                return
            if q not in name.lower() and q not in p.lower():
                return
            try:
                st = (Path(dirpath) / name).stat()
                size: int | None = None if is_dir else st.st_size
                mtime: int | None = int(st.st_mtime)
            except OSError:
                size = None
                mtime = None
            results.append(
                FilesystemEntry(
                    id=p,
                    name=name,
                    path=p,
                    type="directory" if is_dir else "file",
                    bytes=size,
                    modified_at=mtime,
                )
            )

        def scan(root: str, defer: bool) -> None:
            # A query matching little or nothing never fills the result cap, so
            # the walk needs its own bound. Counted per entry: a per-directory
            # check lets one huge directory overshoot before `truncated` trips.
            nonlocal scanned, truncated, stop
            for dirpath, dirnames, filenames in os.walk(root):
                kept = []
                for d in sorted(dirnames):
                    if d == ".git":
                        # Git's own store is never a search target, and in a
                        # plain clone its reflogs alone can outnumber the tree.
                        continue
                    full = os.path.join(dirpath, d)
                    dp = rel(dirpath, d)
                    if any(r.match(dp) for r in exc):
                        continue
                    if defer and d in _DEFAULT_DEPRIORITIZED_DIRS:
                        # Match the dir now, but walk its subtree later (pass 2)
                        # so it can't starve the real tree of scan budget. Never
                        # defer a symlinked dir: os.walk(root) follows a top-level
                        # symlink, so a committed 'node_modules -> ..' would let
                        # pass 2 escape the workspace. os.walk(followlinks=False)
                        # never crosses symlinks mid-tree; deferring only real
                        # dirs keeps that boundary intact.
                        if not os.path.islink(full):
                            deferred.append(full)
                    kept.append(d)
                dirnames[:] = [d for d in kept if not (defer and d in _DEFAULT_DEPRIORITIZED_DIRS)]
                for dname in kept:
                    # Count then check `> budget`, not `>= budget`: a tree of
                    # exactly `budget` entries is fully enumerable and must not
                    # report truncated.
                    scanned += 1
                    if scanned > _SEARCH_SCAN_BUDGET:
                        truncated = True
                        stop = True
                        return
                    match(dirpath, dname, is_dir=True)
                    if len(results) >= limit:
                        stop = True
                        return
                for fname in sorted(filenames):
                    scanned += 1
                    if scanned > _SEARCH_SCAN_BUDGET:
                        truncated = True
                        stop = True
                        return
                    match(dirpath, fname, is_dir=False)
                    if len(results) >= limit:
                        stop = True
                        return

        # Pass 1 walks the real tree and defers dependency/cache subtrees;
        # reordering siblings isn't enough, because a deep node_modules nested
        # under an earlier-sorted real dir would still swallow the whole budget
        # before the walk reached a later top-level dir. Pass 2 drains the
        # deferred roots only if budget remains. Mirrors the runner's walk.
        scan(str(self._root), True)
        while deferred and not stop:
            scan(deferred.popleft(), False)
        # When the walk stops early it is always because scan() tripped the
        # budget (which sets truncated) or the result limit (signaled by
        # has_more); the loop exits only once deferred is drained or stop is
        # set, so no extra truncation flag is needed here.

        results.sort(key=lambda entry: entry.path)
        if indexed is not None:
            results = merge_entries(indexed, results, limit)
        return self._search_payload(results, limit, truncated=truncated)

    @staticmethod
    def _search_payload(
        entries: list[FilesystemEntry], limit: int, *, truncated: bool
    ) -> _WorkspacePayload:
        """Wrap search *entries* in the runner's ``/search`` response shape.

        :param entries: Matching entries, already sorted and capped.
        :param limit: The cap, so ``has_more`` reads the same as the runner's.
        :param truncated: Whether the scan stopped before covering the tree.
        :returns: The list payload.
        """
        return {
            "object": "list",
            "data": [entry_payload(e) for e in entries],
            "has_more": len(entries) >= limit,
            "truncated": truncated,
        }

    # ── Changed files / diff ───────────────────────────────────────

    def changes(self, session_id: str) -> _WorkspacePayload:
        """List changed files, mirroring ``list_filesystem_changes``.

        Git workspaces report the working-tree diff (``git status``);
        non-git workspaces report an empty list because the host has no
        access to the live agent's in-memory edit history.

        :param session_id: Session id (used only by the edit-tracking
            registry; ignored in git mode).
        :returns: A list payload of changed-file entries.
        :raises WorkspaceReaderError: 500 when ``git status`` fails.
        """
        try:
            raw_changes = self._registry.list_changed_files(session_id, limit=10_000)
        except GitStatusUnavailable as exc:
            raise WorkspaceReaderError(500, "git_status_failed", exc.reason) from exc
        data = [
            {
                "object": "session.environment.filesystem.entry",
                "path": rec["path"],
                "name": rec["path"].split("/")[-1],
                "status": rec["status"],
                "bytes": rec.get("bytes"),
                "modified_at": rec.get("modified_at"),
                "lines_added": rec.get("lines_added"),
                "lines_removed": rec.get("lines_removed"),
            }
            for rec in raw_changes
        ]
        return {"object": "list", "data": data, "has_more": False}

    def diff(self, session_id: str, relative_path: str) -> _WorkspacePayload:
        """Return before/after content, mirroring the runner diff endpoint.

        :param session_id: Session id (git mode ignores it).
        :param relative_path: Path relative to the workspace root.
        :returns: A file-diff dict with ``before``/``after`` strings.
        :raises WorkspaceReaderError: On invalid path, git failure, or a
            path not in the changed-files registry (404).
        """
        try:
            relative_path = _validate_path(relative_path)
        except InvalidPath as exc:
            raise WorkspaceReaderError(400, "invalid_path", str(exc)) from exc
        if not relative_path:
            raise WorkspaceReaderError(400, "invalid_path", "Cannot diff the workspace root")

        try:
            record = self._registry.get_changed_file(session_id, relative_path)
        except GitStatusUnavailable as exc:
            raise WorkspaceReaderError(500, "git_status_failed", exc.reason) from exc
        if record is None:
            raise WorkspaceReaderError(
                404,
                "not_found",
                f"Path {relative_path!r} is not in the changed-files registry for this session",
            )

        is_deleted = record.get("status") == "deleted"
        before: str | None = self._registry.get_baseline(relative_path)
        after: str | None = None
        if not is_deleted:
            resolved = self._resolve(relative_path)
            try:
                # Bounded read (like _read_file) so a huge changed file can't
                # OOM the host; the diff view caps at _MAX_READ_BYTES anyway.
                with resolved.open("rb") as fh:
                    raw = fh.read(_MAX_READ_BYTES)
                after = raw.decode("utf-8", errors="replace")
            except OSError:
                after = None
        return {
            "object": "session.environment.filesystem.file_diff",
            "path": relative_path,
            "before": before,
            "after": after,
        }

    # ── GitHub integration (read-only) ────────────────────────────
    # Serve the same read-only PR metadata + the PR's files / diff the runner's
    # GitHub endpoints do, so the tab keeps working when the runner is offline
    # but the host still holds the workspace. Delegates to the shared
    # ``github_resource`` helpers against this reader's confined root; the list
    # and patch come from ``gh`` (the developer's authenticated CLI) and only the
    # per-file reader shells out to a read-only ``git show``.

    def github_info(
        self, session_id: str | None = None, pr_url: str | None = None
    ) -> _WorkspacePayload:
        """GitHub context for an explicit session PR or the workspace branch."""
        return cast(
            "_WorkspacePayload",
            github_resource.github_info(
                str(self._root),
                session_id=session_id,
                pr_url=pr_url,
            ),
        )

    def github_changes(
        self, session_id: str | None = None, pr_url: str | None = None
    ) -> _WorkspacePayload:
        """The selected PR's changed files."""
        return cast(
            "_WorkspacePayload",
            github_resource.github_changed_files(
                str(self._root),
                session_id=session_id,
                pr_url=pr_url,
            ),
        )

    def github_file_diff(
        self,
        base: str | None,
        relative_path: str,
        session_id: str | None = None,
        pr_url: str | None = None,
        previous_path: str | None = None,
        head_sha: str | None = None,
        base_sha: str | None = None,
    ) -> _WorkspacePayload:
        """Before/after content for the selected PR's revisions."""
        return cast(
            "_WorkspacePayload",
            github_resource.github_file_diff(
                str(self._root),
                base or "",
                relative_path,
                session_id=session_id,
                pr_url=pr_url,
                previous_path=previous_path,
                head_sha=head_sha,
                base_sha=base_sha,
            ),
        )

    def github_pr_diff(
        self, session_id: str | None = None, pr_url: str | None = None
    ) -> _WorkspacePayload:
        """The selected PR's unified diff patch."""
        return cast(
            "_WorkspacePayload",
            github_resource.github_pr_diff(
                str(self._root),
                session_id=session_id,
                pr_url=pr_url,
            ),
        )
